# Simple Shutdown Guide (Windows PowerShell)

এই ফাইলের কমান্ডগুলো দিয়ে `video_call` project এর চলমান server, tunnel, এবং নির্দিষ্ট port use করা process বন্ধ করতে পারবেন।

## 1) যেসব process সাধারণত বন্ধ করতে হবে

```powershell
# Node server processes
Get-Process node -ErrorAction SilentlyContinue | Stop-Process -Force

# Cloudflare tunnel process
Get-Process cloudflared -ErrorAction SilentlyContinue | Stop-Process -Force
```

## 2) নির্দিষ্ট port ফাঁকা করা (3000, 3443)

```powershell
$ports = 3000, 3443

foreach ($port in $ports) {
  $pids = Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue |
    Select-Object -ExpandProperty OwningProcess -Unique

  foreach ($pid in $pids) {
    Write-Host "Stopping PID $pid on port $port"
    Stop-Process -Id $pid -Force -ErrorAction SilentlyContinue
  }
}
```

## 3) সব listening Node process বন্ধ করা (safe one-liner)

```powershell
Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue |
  ForEach-Object { $_.OwningProcess } |
  Sort-Object -Unique |
  ForEach-Object {
    $p = Get-Process -Id $_ -ErrorAction SilentlyContinue
    if ($p -and $p.ProcessName -eq "node") {
      Stop-Process -Id $_ -Force -ErrorAction SilentlyContinue
    }
  }
```

## 4) verify করুন port free কিনা

```powershell
Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue |
  Where-Object { $_.LocalPort -in 3000,3443 } |
  Select-Object LocalAddress, LocalPort, State, OwningProcess
```

Expected: কোন output না এলে port ফাঁকা।

## 5) সবকিছু একসাথে shutdown (quick copy-paste)

```powershell
Get-Process node,cloudflared -ErrorAction SilentlyContinue | Stop-Process -Force

3000,3443 | ForEach-Object {
  Get-NetTCPConnection -LocalPort $_ -State Listen -ErrorAction SilentlyContinue |
    Select-Object -ExpandProperty OwningProcess -Unique |
    ForEach-Object { Stop-Process -Id $_ -Force -ErrorAction SilentlyContinue }
}
```

