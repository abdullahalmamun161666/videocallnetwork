const path = require("path");
const fs = require("fs");
const os = require("os");
const express = require("express");
const http = require("http");
const https = require("https");
const cors = require("cors");
const session = require("express-session");
const { Server } = require("socket.io");
const { registerSocketHandlers } = require("./socket");

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

const sessionSecret = process.env.SESSION_SECRET || "change-this-session-secret";
const sessionMiddleware = session({
  secret: sessionSecret,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "lax",
    secure: false,
    maxAge: 1000 * 60 * 60 * 24 * 7,
  },
});
app.use(sessionMiddleware);

const clientDir = path.join(__dirname, "..", "client");

function loadAllowedUsers() {
  const fromJson = process.env.AUTH_USERS_JSON;
  if (fromJson) {
    try {
      const parsed = JSON.parse(fromJson);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed
          .filter((item) => item && item.username && item.password)
          .map((item) => ({
            username: String(item.username),
            password: String(item.password),
          }));
      }
    } catch (error) {
      console.error("Invalid AUTH_USERS_JSON value. Falling back to default user.", error);
    }
  }

  const singleUser = process.env.AUTH_USERNAME || "team";
  const singlePass = process.env.AUTH_PASSWORD || "team123";
  return [{ username: singleUser, password: singlePass }];
}

const allowedUsers = loadAllowedUsers();

function isAuthenticated(req) {
  return Boolean(req.session && req.session.user);
}

function authGuard(req, res, next) {
  if (isAuthenticated(req)) {
    return next();
  }
  return res.redirect("/login");
}

app.get("/health", (_req, res) => {
  res.json({ status: "ok" });
});

app.get("/login", (req, res) => {
  if (isAuthenticated(req)) {
    return res.redirect("/");
  }
  return res.sendFile(path.join(clientDir, "login.html"));
});

app.post("/login", (req, res) => {
  const username = typeof req.body.username === "string" ? req.body.username.trim() : "";
  const password = typeof req.body.password === "string" ? req.body.password : "";
  const matchedUser = allowedUsers.find(
    (user) => user.username === username && user.password === password,
  );

  if (!matchedUser) {
    return res.status(401).sendFile(path.join(clientDir, "login.html"));
  }

  req.session.user = { username: matchedUser.username };
  return res.redirect("/");
});

app.post("/logout", (req, res) => {
  req.session.destroy(() => {
    res.redirect("/login");
  });
});

app.use(authGuard);
app.use(express.static(clientDir));

function getLocalIpAddresses() {
  const interfaces = os.networkInterfaces();
  const ips = [];
  Object.values(interfaces).forEach((list) => {
    (list || []).forEach((item) => {
      if (item && item.family === "IPv4" && !item.internal) {
        ips.push(item.address);
      }
    });
  });
  return ips;
}

const sslKeyPath = process.env.SSL_KEY_PATH;
const sslCertPath = process.env.SSL_CERT_PATH;
const hasHttpsConfig = Boolean(sslKeyPath && sslCertPath);

const server = hasHttpsConfig
  ? https.createServer(
      {
        key: fs.readFileSync(sslKeyPath),
        cert: fs.readFileSync(sslCertPath),
      },
      app,
    )
  : http.createServer(app);

const io = new Server(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"],
  },
});

io.use((socket, next) => {
  sessionMiddleware(socket.request, {}, () => {
    if (socket.request.session && socket.request.session.user) {
      return next();
    }
    return next(new Error("Unauthorized"));
  });
});

io.on("connection", (socket) => {
  registerSocketHandlers(io, socket);
});

const PORT = process.env.PORT || (hasHttpsConfig ? 3443 : 3000);
const HOST = process.env.HOST || "0.0.0.0";

server.listen(PORT, HOST, () => {
  const protocol = hasHttpsConfig ? "https" : "http";
  const localIps = getLocalIpAddresses();

  console.log(`Signaling server running on ${protocol}://localhost:${PORT}`);
  localIps.forEach((ip) => {
    console.log(`LAN URL: ${protocol}://${ip}:${PORT}`);
  });

  if (!hasHttpsConfig) {
    console.log(
      "Warning: running on HTTP. Mobile browsers may block camera/microphone on non-HTTPS origins.",
    );
  }
});
