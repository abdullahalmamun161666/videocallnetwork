const rooms = new Map();
const socketToRoom = new Map();
const users = new Map();
const groups = new Map(); // roomId -> { roomId, name, creatorId, creatorName }

function buildRoomId(userIdA, userIdB) {
  return [userIdA, userIdB].sort().join("__");
}

function getOnlineUsersList() {
  return [...users.entries()].map(([userId, user]) => ({
    userId,
    name: user.name,
  }));
}

function broadcastOnlineUsers(io) {
  io.emit("online-users", getOnlineUsersList());
}

function getRoomMembers(roomId) {
  if (!rooms.has(roomId)) {
    rooms.set(roomId, new Set());
  }
  return rooms.get(roomId);
}

function joinRoom(socket, roomId) {
  const currentRoomId = socketToRoom.get(socket.id);
  if (currentRoomId && currentRoomId !== roomId) {
    leaveRoom(socket);
  }

  const members = getRoomMembers(roomId);
  const existingUsers = [...members];

  members.add(socket.id);
  socketToRoom.set(socket.id, roomId);
  socket.join(roomId);

  return existingUsers;
}

function leaveRoom(socket) {
  const roomId = socketToRoom.get(socket.id);
  if (!roomId) {
    return null;
  }

  const members = rooms.get(roomId);
  if (members) {
    members.delete(socket.id);
    if (members.size === 0) {
      rooms.delete(roomId);
    }
  }

  socketToRoom.delete(socket.id);
  socket.leave(roomId);

  return roomId;
}

function generateGroupRoomId() {
  const random = Math.random().toString(36).slice(2, 8);
  return `group-${Date.now()}-${random}`;
}

function getAvailableGroupsList() {
  return [...groups.values()].map((group) => ({
    roomId: group.roomId,
    name: group.name,
    creatorId: group.creatorId,
    creatorName: group.creatorName,
    memberCount: rooms.has(group.roomId) ? rooms.get(group.roomId).size : 0,
  }));
}

function broadcastAvailableGroups(io) {
  io.emit("available-groups", getAvailableGroupsList());
}

function registerSocketHandlers(io, socket) {
  socket.on("register-user", ({ name }) => {
    const trimmedName = typeof name === "string" ? name.trim() : "";
    const safeName = trimmedName || `User-${socket.id.slice(0, 5)}`;
    users.set(socket.id, { name: safeName });
    socket.emit("user-registered", { userId: socket.id, name: safeName });
    broadcastOnlineUsers(io);
  });

  // Create a named group. The creator is registered as the owner but is NOT
  // joined to the room here -- they must click "Join Group" like anyone else.
  socket.on("create-group", ({ groupName }) => {
    const creator = users.get(socket.id);
    if (!creator) {
      socket.emit("error-message", { message: "Please set your name first." });
      return;
    }

    const trimmedName = typeof groupName === "string" ? groupName.trim() : "";
    if (!trimmedName) {
      socket.emit("error-message", { message: "Group name is required." });
      return;
    }

    const roomId = generateGroupRoomId();
    const group = {
      roomId,
      name: trimmedName,
      creatorId: socket.id,
      creatorName: creator.name,
    };
    groups.set(roomId, group);

    socket.emit("group-created", group);
    broadcastAvailableGroups(io);
  });

  socket.on("join-room", ({ roomId }) => {
    if (!roomId || typeof roomId !== "string") {
      socket.emit("error-message", { message: "Invalid roomId." });
      return;
    }

    const normalizedRoomId = roomId.trim();
    const existingUsers = joinRoom(socket, normalizedRoomId);
    socket.emit("all-users", existingUsers);
    socket.to(normalizedRoomId).emit("user-joined", { userId: socket.id });

    if (groups.has(normalizedRoomId)) {
      broadcastAvailableGroups(io);
    }
  });

  socket.on("leave-room", () => {
    const roomId = leaveRoom(socket);
    if (roomId) {
      socket.to(roomId).emit("user-left", { userId: socket.id });
      if (groups.has(roomId)) {
        broadcastAvailableGroups(io);
      }
    }
  });

  socket.on("call-user", ({ targetUserId }) => {
    if (!targetUserId || !users.has(targetUserId) || targetUserId === socket.id) {
      socket.emit("error-message", { message: "Target user is not available." });
      return;
    }

    const caller = users.get(socket.id);
    if (!caller) {
      socket.emit("error-message", { message: "Please set your name first." });
      return;
    }

    const roomId = buildRoomId(socket.id, targetUserId);
    io.to(targetUserId).emit("incoming-call", {
      fromUserId: socket.id,
      fromName: caller.name,
      roomId,
    });
  });

  socket.on("accept-call", ({ callerUserId, roomId }) => {
    if (!callerUserId || !roomId) {
      return;
    }
    io.to(callerUserId).emit("call-accepted", {
      byUserId: socket.id,
      roomId,
    });
  });

  socket.on("decline-call", ({ callerUserId }) => {
    if (!callerUserId) {
      return;
    }
    io.to(callerUserId).emit("call-declined", { byUserId: socket.id });
  });

  socket.on("offer", ({ targetUserId, sdp }) => {
    io.to(targetUserId).emit("offer", { senderUserId: socket.id, sdp });
  });

  socket.on("answer", ({ targetUserId, sdp }) => {
    io.to(targetUserId).emit("answer", { senderUserId: socket.id, sdp });
  });

  socket.on("ice-candidate", ({ targetUserId, candidate }) => {
    io.to(targetUserId).emit("ice-candidate", {
      senderUserId: socket.id,
      candidate,
    });
  });

  socket.on("disconnect", () => {
    const roomId = leaveRoom(socket);
    if (roomId) {
      socket.to(roomId).emit("user-left", { userId: socket.id });
      if (groups.has(roomId)) {
        broadcastAvailableGroups(io);
      }
    }
    users.delete(socket.id);
    broadcastOnlineUsers(io);
  });
}

module.exports = { registerSocketHandlers };
