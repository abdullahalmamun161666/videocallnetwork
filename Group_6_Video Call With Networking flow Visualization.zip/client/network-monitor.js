(function initNetworkMonitor(global) {
  // This module collects REAL data from the browser's WebRTC stack.
  // It never creates its own RTCPeerConnection -- callers (app.js) register
  // the SAME pc objects that PeersModule already created for the call.

  const POLL_INTERVAL_MS = 1000;

  const trackedPeers = new Map(); // userId -> RTCPeerConnection
  const previousSamples = new Map(); // userId -> { t, bytesSent, bytesReceived, packetsSent, packetsReceived }

  let timerId = null;
  let onSample = null; // (userId, summary) => void
  let onPeerRemoved = null; // (userId) => void

  function addPeer(userId, pc) {
    trackedPeers.set(userId, pc);
  }

  function removePeer(userId) {
    trackedPeers.delete(userId);
    previousSamples.delete(userId);
    if (onPeerRemoved) {
      onPeerRemoved(userId);
    }
  }

  function clearAllPeers() {
    trackedPeers.clear();
    previousSamples.clear();
  }

  function pickSelectedCandidatePair(report) {
    let transportSelectedId = null;
    let fallbackPair = null;

    report.forEach((entry) => {
      if (entry.type === "transport" && entry.selectedCandidatePairId) {
        transportSelectedId = entry.selectedCandidatePairId;
      }
      if (entry.type === "candidate-pair") {
        // Some browsers set `selected`, others only mark state === "succeeded"
        // with nominated === true. Keep the best candidate we see.
        if (entry.selected === true) {
          fallbackPair = entry;
        } else if (!fallbackPair && (entry.nominated || entry.state === "succeeded")) {
          fallbackPair = entry;
        }
      }
    });

    if (transportSelectedId && report.get(transportSelectedId)) {
      return report.get(transportSelectedId);
    }
    return fallbackPair;
  }

  async function summarizeStats(userId, pc) {
    const report = await pc.getStats();

    const candidatePair = pickSelectedCandidatePair(report);
    const localCandidate = candidatePair ? report.get(candidatePair.localCandidateId) : null;
    const remoteCandidate = candidatePair ? report.get(candidatePair.remoteCandidateId) : null;

    const codecsById = {};
    let inboundVideo = null;
    let inboundAudio = null;
    let outboundVideo = null;
    let outboundAudio = null;
    let remoteInboundRtt = null;

    report.forEach((entry) => {
      if (entry.type === "codec") {
        codecsById[entry.id] = entry.mimeType || null;
      }
      if (entry.type === "inbound-rtp" && !entry.isRemote) {
        if (entry.kind === "video") inboundVideo = entry;
        if (entry.kind === "audio") inboundAudio = entry;
      }
      if (entry.type === "outbound-rtp" && !entry.isRemote) {
        if (entry.kind === "video") outboundVideo = entry;
        if (entry.kind === "audio") outboundAudio = entry;
      }
      if (entry.type === "remote-inbound-rtp" && typeof entry.roundTripTime === "number") {
        remoteInboundRtt = entry.roundTripTime;
      }
    });

    const bytesSent = (outboundVideo ? outboundVideo.bytesSent || 0 : 0) + (outboundAudio ? outboundAudio.bytesSent || 0 : 0);
    const bytesReceived = (inboundVideo ? inboundVideo.bytesReceived || 0 : 0) + (inboundAudio ? inboundAudio.bytesReceived || 0 : 0);
    const packetsSent = (outboundVideo ? outboundVideo.packetsSent || 0 : 0) + (outboundAudio ? outboundAudio.packetsSent || 0 : 0);
    const packetsReceived = (inboundVideo ? inboundVideo.packetsReceived || 0 : 0) + (inboundAudio ? inboundAudio.packetsReceived || 0 : 0);
    const packetsLost = (inboundVideo ? inboundVideo.packetsLost || 0 : 0) + (inboundAudio ? inboundAudio.packetsLost || 0 : 0);

    const now = performance.now();
    const previous = previousSamples.get(userId);
    let outgoingKbps = null;
    let incomingKbps = null;
    if (previous) {
      const dtSeconds = (now - previous.t) / 1000;
      if (dtSeconds > 0) {
        outgoingKbps = Math.max(0, ((bytesSent - previous.bytesSent) * 8) / dtSeconds / 1000);
        incomingKbps = Math.max(0, ((bytesReceived - previous.bytesReceived) * 8) / dtSeconds / 1000);
      }
    }
    previousSamples.set(userId, { t: now, bytesSent, bytesReceived, packetsSent, packetsReceived });

    let rttMs = null;
    if (candidatePair && typeof candidatePair.currentRoundTripTime === "number") {
      rttMs = candidatePair.currentRoundTripTime * 1000;
    } else if (typeof remoteInboundRtt === "number") {
      rttMs = remoteInboundRtt * 1000;
    }

    const protocol = localCandidate && localCandidate.protocol ? localCandidate.protocol.toUpperCase() : null;

    const videoCodec = outboundVideo && outboundVideo.codecId ? codecsById[outboundVideo.codecId] : inboundVideo && inboundVideo.codecId ? codecsById[inboundVideo.codecId] : null;
    const audioCodec = outboundAudio && outboundAudio.codecId ? codecsById[outboundAudio.codecId] : inboundAudio && inboundAudio.codecId ? codecsById[inboundAudio.codecId] : null;

    return {
      userId,
      connectionState: pc.connectionState,
      iceConnectionState: pc.iceConnectionState,
      signalingState: pc.signalingState,
      hasSelectedPair: Boolean(candidatePair),
      protocol, // 'UDP' | 'TCP' | null (browser did not expose it)
      localCandidateType: localCandidate ? localCandidate.candidateType : null,
      remoteCandidateType: remoteCandidate ? remoteCandidate.candidateType : null,
      localAddress: localCandidate ? localCandidate.address || localCandidate.ip || null : null,
      remoteAddress: remoteCandidate ? remoteCandidate.address || remoteCandidate.ip || null : null,
      localPort: localCandidate ? localCandidate.port : null,
      remotePort: remoteCandidate ? remoteCandidate.port : null,
      networkType: localCandidate ? localCandidate.networkType || null : null,
      videoCodec,
      audioCodec,
      bytesSent,
      bytesReceived,
      packetsSent,
      packetsReceived,
      packetsLost,
      rttMs,
      outgoingKbps,
      incomingKbps,
    };
  }

  async function pollOnce() {
    const jobs = [];
    trackedPeers.forEach((pc, userId) => {
      jobs.push(
        summarizeStats(userId, pc)
          .then((summary) => {
            if (onSample) onSample(userId, summary);
          })
          .catch((error) => {
            console.error(`[network-monitor] getStats failed for ${userId}`, error);
          }),
      );
    });
    await Promise.all(jobs);
  }

  function start(sampleHandler, removedHandler) {
    onSample = sampleHandler || null;
    onPeerRemoved = removedHandler || null;
    if (timerId) {
      return;
    }
    pollOnce();
    timerId = setInterval(pollOnce, POLL_INTERVAL_MS);
  }

  function stop() {
    if (timerId) {
      clearInterval(timerId);
      timerId = null;
    }
  }

  function isRunning() {
    return Boolean(timerId);
  }

  function hasPeers() {
    return trackedPeers.size > 0;
  }

  function getTrackedUserIds() {
    return Array.from(trackedPeers.keys());
  }

  global.NetworkMonitorModule = {
    addPeer,
    removePeer,
    clearAllPeers,
    start,
    stop,
    isRunning,
    hasPeers,
    getTrackedUserIds,
  };
})(window);
