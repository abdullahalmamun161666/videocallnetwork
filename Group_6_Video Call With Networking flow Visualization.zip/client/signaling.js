(function initSignalingModule(global) {
  function createSignalingClient() {
    const socket = io();

    return {
      getSocketId: () => socket.id,
      onConnect: (handler) => socket.on("connect", handler),
      onDisconnect: (handler) => socket.on("disconnect", handler),
      onErrorMessage: (handler) => socket.on("error-message", handler),
      onUserRegistered: (handler) => socket.on("user-registered", handler),
      onOnlineUsers: (handler) => socket.on("online-users", handler),
      onIncomingCall: (handler) => socket.on("incoming-call", handler),
      onCallAccepted: (handler) => socket.on("call-accepted", handler),
      onCallDeclined: (handler) => socket.on("call-declined", handler),
      onGroupCreated: (handler) => socket.on("group-created", handler),
      onAvailableGroups: (handler) => socket.on("available-groups", handler),
      onAllUsers: (handler) => socket.on("all-users", handler),
      onUserJoined: (handler) => socket.on("user-joined", handler),
      onUserLeft: (handler) => socket.on("user-left", handler),
      onOffer: (handler) => socket.on("offer", handler),
      onAnswer: (handler) => socket.on("answer", handler),
      onIceCandidate: (handler) => socket.on("ice-candidate", handler),
      registerUser: (name) => socket.emit("register-user", { name }),
      callUser: (targetUserId) => socket.emit("call-user", { targetUserId }),
      createGroup: (groupName) => socket.emit("create-group", { groupName }),
      acceptCall: (callerUserId, roomId) => socket.emit("accept-call", { callerUserId, roomId }),
      declineCall: (callerUserId) => socket.emit("decline-call", { callerUserId }),
      joinRoom: (roomId) => socket.emit("join-room", { roomId }),
      leaveRoom: () => socket.emit("leave-room"),
      sendOffer: (targetUserId, sdp) => socket.emit("offer", { targetUserId, sdp }),
      sendAnswer: (targetUserId, sdp) => socket.emit("answer", { targetUserId, sdp }),
      sendIceCandidate: (targetUserId, candidate) =>
        socket.emit("ice-candidate", { targetUserId, candidate }),
    };
  }

  global.SignalingModule = { createSignalingClient };
})(window);
