(function initPeersModule(global) {
  const peers = {};
  const pendingCandidates = {};
  const remoteStreams = {};
  const defaultRtcConfig = {
    iceServers: [{ urls: "stun:stun.l.google.com:19302" }],
  };

  function createPeerConnection(userId, options) {
    if (peers[userId]) {
      return peers[userId];
    }

    const {
      rtcConfig = defaultRtcConfig,
      localStream,
      onRemoteTrack,
      onIceCandidate,
      onConnectionStateChange,
    } = options;

    const pc = new RTCPeerConnection(rtcConfig);
    peers[userId] = pc;
    pendingCandidates[userId] = pendingCandidates[userId] || [];

    if (localStream) {
      localStream.getTracks().forEach((track) => {
        pc.addTrack(track, localStream);
      });
    }

    pc.ontrack = (event) => {
      let remoteStream = event.streams && event.streams[0];
      if (!remoteStream) {
        // Some browsers fire ontrack without populated event.streams.
        // Keep a per-peer stream and add incoming tracks to it.
        remoteStreams[userId] = remoteStreams[userId] || new MediaStream();
        remoteStreams[userId].addTrack(event.track);
        remoteStream = remoteStreams[userId];
      } else {
        remoteStreams[userId] = remoteStream;
      }

      if (onRemoteTrack && remoteStream) {
        onRemoteTrack(userId, remoteStream);
      }
    };

    pc.onicecandidate = (event) => {
      if (event.candidate && onIceCandidate) {
        onIceCandidate(userId, event.candidate);
      }
    };

    pc.onconnectionstatechange = () => {
      if (onConnectionStateChange) {
        onConnectionStateChange(userId, pc.connectionState);
      }
    };

    return pc;
  }

  async function setRemoteDescription(userId, sdp) {
    const pc = peers[userId];
    if (!pc) {
      return;
    }

    await pc.setRemoteDescription(new RTCSessionDescription(sdp));

    if (pendingCandidates[userId] && pendingCandidates[userId].length > 0) {
      for (const candidate of pendingCandidates[userId]) {
        await pc.addIceCandidate(new RTCIceCandidate(candidate));
      }
      pendingCandidates[userId] = [];
    }
  }

  async function addIceCandidate(userId, candidate) {
    const pc = peers[userId];
    if (!pc) {
      return;
    }

    if (pc.remoteDescription && pc.remoteDescription.type) {
      await pc.addIceCandidate(new RTCIceCandidate(candidate));
      return;
    }

    pendingCandidates[userId] = pendingCandidates[userId] || [];
    pendingCandidates[userId].push(candidate);
  }

  function closePeer(userId) {
    const pc = peers[userId];
    if (pc) {
      pc.close();
      delete peers[userId];
    }
    delete pendingCandidates[userId];
    delete remoteStreams[userId];
  }

  function closeAllPeers() {
    Object.keys(peers).forEach(closePeer);
  }

  function hasPeer(userId) {
    return Boolean(peers[userId]);
  }

  function getPeer(userId) {
    return peers[userId];
  }

  global.PeersModule = {
    createPeerConnection,
    setRemoteDescription,
    addIceCandidate,
    closePeer,
    closeAllPeers,
    hasPeer,
    getPeer,
  };
})(window);
