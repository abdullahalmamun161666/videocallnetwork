(function initNetworkFlowUI(global) {
  // Canonical OSI layer metadata (Layers 7, 4, 3, 2, 1 only -- matches the
  // feature spec). "detected" layers have at least one field that really
  // comes from getStats(); "conceptual" layers are educational-only because
  // browser JavaScript cannot read raw frames or physical signals.
  const OSI_LAYERS = [
    {
      code: "L7",
      name: "Application",
      conceptLabel: "WebRTC / SRTP / RTP",
      detectionTag: "Partly detected",
      explain:
        "WebRTC manages real-time audio/video communication between peers. The codec shown in the statistics card (e.g. VP8, Opus) is actually read from this call; SRTP encryption is mandatory in the WebRTC spec, not something JavaScript can toggle off.",
    },
    {
      code: "L4",
      name: "Transport",
      conceptLabel: "UDP / TCP",
      detectionTag: "Partly detected",
      explain:
        "WebRTC commonly prefers UDP for real-time media because low latency matters more than retransmitting every lost packet -- but it can fall back to TCP (e.g. through a TURN/TCP relay) when UDP is blocked. The Connection Details card below shows which one this specific call is actually using, when the browser exposes it.",
    },
    {
      code: "L3",
      name: "Network",
      conceptLabel: "IPv4 / IPv6",
      detectionTag: "Conceptual",
      explain:
        "IP provides addressing and routing so packets can find their way between networks. Browsers intentionally avoid exposing full IP-layer detail to JavaScript for privacy, so this layer is shown conceptually.",
    },
    {
      code: "L2",
      name: "Data Link",
      conceptLabel: "Ethernet / Wi-Fi",
      detectionTag: "Conceptual",
      explain:
        "Ethernet or Wi-Fi carries frames across the local network segment. Browser JavaScript has no API to read raw frames, so this layer is educational only -- use Wireshark on the machine itself to see real frames.",
    },
    {
      code: "L1",
      name: "Physical",
      conceptLabel: "Electrical / Radio Signal",
      detectionTag: "Conceptual",
      explain:
        "Data ultimately travels as electrical, optical, or radio signals over the physical medium. No web browser can access this layer from JavaScript -- it is shown here purely for educational completeness.",
    },
  ];

  let els = {};
  let educationalMode = false;
  let selectedUserId = null;
  const peerNames = new Map(); // userId -> display name
  const latestSamples = new Map(); // userId -> last summary from NetworkMonitorModule
  let animTimerOut = null;
  let animTimerIn = null;

  function q(id) {
    return document.getElementById(id);
  }

  function cacheDom() {
    els = {
      panel: q("networkFlowPanel"),
      monitorButton: q("monitorToggleButton"),
      eduToggle: q("eduModeToggle"),
      peerTabs: q("nfPeerTabs"),
      osiStackOut: q("osiStackOut"),
      osiStackIn: q("osiStackIn"),
      osiInfoList: q("osiInfoList"),
      osiExplain: q("osiExplain"),
      statsBadge: q("statsBadge"),
      packetStatsGrid: q("packetStatsGrid"),
      connectionDetailsGrid: q("connectionDetailsGrid"),
    };
  }

  function buildLaneNodes(direction) {
    // direction: 'out' (source -> network) or 'in' (network -> output)
    const nodes = [];
    if (direction === "out") {
      nodes.push({ key: "source", label: "Camera / Microphone" });
      OSI_LAYERS.forEach((layer) => nodes.push({ key: layer.code, label: `${layer.code} ${layer.name}`, sub: layer.conceptLabel }));
      nodes.push({ key: "network", label: "NETWORK", isNetwork: true });
    } else {
      nodes.push({ key: "network", label: "NETWORK", isNetwork: true });
      [...OSI_LAYERS].reverse().forEach((layer) => nodes.push({ key: layer.code, label: `${layer.code} ${layer.name}`, sub: layer.conceptLabel }));
      nodes.push({ key: "output", label: "Video / Audio Output" });
    }
    return nodes;
  }

  function renderLane(container, direction) {
    container.innerHTML = "";
    buildLaneNodes(direction).forEach((node) => {
      const box = document.createElement("div");
      box.className = "nf-layer" + (node.isNetwork ? " nf-layer-network" : "");
      box.dataset.key = node.key;
      const title = document.createElement("span");
      title.className = "nf-layer-title";
      title.textContent = node.label;
      box.appendChild(title);
      if (node.sub) {
        const sub = document.createElement("span");
        sub.className = "nf-layer-sub";
        sub.textContent = node.sub;
        box.appendChild(sub);
      }
      container.appendChild(box);
    });
  }

  function renderOsiInfoList() {
    els.osiInfoList.innerHTML = "";
    OSI_LAYERS.forEach((layer) => {
      const item = document.createElement("li");
      item.className = "osi-info-item";
      item.tabIndex = 0;
      item.dataset.code = layer.code;

      const head = document.createElement("div");
      head.className = "osi-info-head";
      const title = document.createElement("strong");
      title.textContent = `${layer.code} - ${layer.name}`;
      const tag = document.createElement("span");
      tag.className = "nf-tag " + (layer.detectionTag === "Conceptual" ? "nf-tag-concept" : "nf-tag-detected");
      tag.textContent = layer.detectionTag;
      head.appendChild(title);
      head.appendChild(tag);

      const sub = document.createElement("p");
      sub.className = "small-text";
      sub.textContent = layer.conceptLabel;

      item.appendChild(head);
      item.appendChild(sub);
      item.addEventListener("click", () => showExplain(layer));
      item.addEventListener("keydown", (event) => {
        if (event.key === "Enter" || event.key === " ") showExplain(layer);
      });
      els.osiInfoList.appendChild(item);
    });
  }

  function showExplain(layer) {
    if (!educationalMode) {
      els.osiExplain.hidden = true;
      return;
    }
    els.osiExplain.hidden = false;
    els.osiExplain.innerHTML = `<strong>${layer.code} - ${layer.name}:</strong> ${layer.explain}`;
  }

  function fmtBytes(n) {
    if (n === null || n === undefined) return "—";
    if (n < 1024) return `${n} B`;
    if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
    return `${(n / (1024 * 1024)).toFixed(2)} MB`;
  }

  function fmtNum(n) {
    return n === null || n === undefined ? "—" : Number(n).toLocaleString();
  }

  function fmtMs(n) {
    return n === null || n === undefined ? "—" : `${Math.round(n)} ms`;
  }

  function fmtKbps(n) {
    return n === null || n === undefined ? "—" : `${n.toFixed(0)} kbps`;
  }

  function notExposed(value) {
    return value === null || value === undefined || value === "" ? "Not exposed by browser" : value;
  }

  function statRow(dl, label, value) {
    const dt = document.createElement("dt");
    dt.textContent = label;
    const dd = document.createElement("dd");
    dd.textContent = value;
    dl.appendChild(dt);
    dl.appendChild(dd);
  }

  function renderEmptyStats() {
    els.packetStatsGrid.innerHTML = "";
    statRow(els.packetStatsGrid, "Connection", "No active call");
    els.statsBadge.textContent = "Not monitoring";
    els.statsBadge.className = "nf-badge";

    els.connectionDetailsGrid.innerHTML = "";
    statRow(els.connectionDetailsGrid, "Status", "Join or start a call to see connection details.");
  }

  function renderSample(summary) {
    els.packetStatsGrid.innerHTML = "";
    statRow(els.packetStatsGrid, "Connection", summary.connectionState || "—");
    statRow(els.packetStatsGrid, "Transport", summary.protocol ? `${summary.protocol} (detected)` : "Detected by WebRTC / Browser");
    statRow(els.packetStatsGrid, "Candidate Type", summary.localCandidateType || "—");
    statRow(els.packetStatsGrid, "Packets Sent", fmtNum(summary.packetsSent));
    statRow(els.packetStatsGrid, "Packets Received", fmtNum(summary.packetsReceived));
    statRow(els.packetStatsGrid, "Bytes Sent", fmtBytes(summary.bytesSent));
    statRow(els.packetStatsGrid, "Bytes Received", fmtBytes(summary.bytesReceived));
    statRow(els.packetStatsGrid, "Packets Lost", fmtNum(summary.packetsLost));
    statRow(els.packetStatsGrid, "RTT", fmtMs(summary.rttMs));
    statRow(els.packetStatsGrid, "Bitrate Out", fmtKbps(summary.outgoingKbps));
    statRow(els.packetStatsGrid, "Bitrate In", fmtKbps(summary.incomingKbps));
    statRow(els.packetStatsGrid, "Video Codec", summary.videoCodec || "—");
    statRow(els.packetStatsGrid, "Audio Codec", summary.audioCodec || "—");

    els.statsBadge.textContent = summary.connectionState === "connected" ? "Live" : summary.connectionState || "—";
    els.statsBadge.className = "nf-badge " + (summary.connectionState === "connected" ? "nf-badge-live" : "");

    els.connectionDetailsGrid.innerHTML = "";
    statRow(els.connectionDetailsGrid, "Local Address", notExposed(summary.localAddress && summary.localPort ? `${summary.localAddress}:${summary.localPort}` : summary.localAddress));
    statRow(els.connectionDetailsGrid, "Remote Address", notExposed(summary.remoteAddress && summary.remotePort ? `${summary.remoteAddress}:${summary.remotePort}` : summary.remoteAddress));
    statRow(els.connectionDetailsGrid, "Local Candidate Type", notExposed(summary.localCandidateType));
    statRow(els.connectionDetailsGrid, "Remote Candidate Type", notExposed(summary.remoteCandidateType));
    statRow(els.connectionDetailsGrid, "Protocol", notExposed(summary.protocol));
    statRow(els.connectionDetailsGrid, "Network Type", notExposed(summary.networkType));
    statRow(els.connectionDetailsGrid, "Connection State", summary.connectionState || "—");
    statRow(els.connectionDetailsGrid, "ICE Connection State", summary.iceConnectionState || "—");
    statRow(els.connectionDetailsGrid, "Signaling State", summary.signalingState || "—");
  }

  function spawnPacket(container, direction) {
    const boxes = container.querySelectorAll(".nf-layer");
    if (boxes.length < 2) return;

    const dot = document.createElement("div");
    dot.className = "nf-packet " + (direction === "out" ? "nf-packet-out" : "nf-packet-in");
    container.style.position = container.style.position || "relative";
    container.appendChild(dot);

    let step = 0;
    const totalSteps = boxes.length - 1;
    const stepDuration = 380;

    function place() {
      const box = boxes[step];
      const boxRect = box.getBoundingClientRect();
      const containerRect = container.getBoundingClientRect();
      const top = boxRect.top - containerRect.top + boxRect.height / 2;
      dot.style.top = `${top}px`;
      dot.style.left = "50%";
    }

    place();
    const interval = setInterval(() => {
      step += 1;
      if (step >= boxes.length) {
        clearInterval(interval);
        dot.remove();
        return;
      }
      place();
      if (step >= totalSteps) {
        setTimeout(() => {
          dot.style.opacity = "0";
          setTimeout(() => dot.remove(), 200);
        }, stepDuration);
      }
    }, stepDuration);
  }

  function renderPeerTabs() {
    const ids = Array.from(latestSamples.keys());
    if (ids.length <= 1) {
      els.peerTabs.hidden = true;
      els.peerTabs.innerHTML = "";
      return;
    }
    els.peerTabs.hidden = false;
    els.peerTabs.innerHTML = "";
    ids.forEach((userId) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "nf-peer-tab" + (userId === selectedUserId ? " active" : "");
      btn.textContent = peerNames.get(userId) || userId.slice(0, 6);
      btn.addEventListener("click", () => {
        selectedUserId = userId;
        renderPeerTabs();
        const sample = latestSamples.get(userId);
        if (sample) renderSample(sample);
      });
      els.peerTabs.appendChild(btn);
    });
  }

  function handleSample(userId, summary) {
    const previous = latestSamples.get(userId);
    latestSamples.set(userId, summary);

    if (!selectedUserId) {
      selectedUserId = userId;
    }
    if (userId === selectedUserId) {
      renderSample(summary);
    }
    renderPeerTabs();

    if (userId === selectedUserId) {
      if (previous && summary.bytesSent > previous.bytesSent) {
        spawnPacket(els.osiStackOut, "out");
      }
      if (previous && summary.bytesReceived > previous.bytesReceived) {
        spawnPacket(els.osiStackIn, "in");
      }
    }
  }

  function updateMonitorButton() {
    const running = global.NetworkMonitorModule.isRunning();
    const hasPeers = global.NetworkMonitorModule.hasPeers();
    els.monitorButton.disabled = !hasPeers;
    els.monitorButton.textContent = running ? "Stop Monitoring" : "Start Monitoring";
  }

  function startMonitoring() {
    global.NetworkMonitorModule.start(handleSample, (userId) => {
      latestSamples.delete(userId);
      peerNames.delete(userId);
      if (selectedUserId === userId) {
        const remaining = Array.from(latestSamples.keys());
        selectedUserId = remaining.length ? remaining[0] : null;
      }
      renderPeerTabs();
      if (selectedUserId) {
        renderSample(latestSamples.get(selectedUserId));
      } else {
        renderEmptyStats();
      }
    });
    updateMonitorButton();
  }

  function stopMonitoring() {
    global.NetworkMonitorModule.stop();
    updateMonitorButton();
  }

  function toggleMonitoring() {
    if (global.NetworkMonitorModule.isRunning()) {
      stopMonitoring();
    } else if (global.NetworkMonitorModule.hasPeers()) {
      startMonitoring();
    }
  }

  function registerPeer(userId, pc, displayName) {
    const wasEmpty = !global.NetworkMonitorModule.hasPeers();
    global.NetworkMonitorModule.addPeer(userId, pc);
    if (displayName) {
      peerNames.set(userId, displayName);
    }
    updateMonitorButton();
    if (wasEmpty) {
      // Auto-start for convenience during a live demo; the button can still
      // pause/resume manually afterward.
      startMonitoring();
    }
  }

  function setPeerName(userId, name) {
    peerNames.set(userId, name);
    renderPeerTabs();
  }

  function unregisterPeer(userId) {
    global.NetworkMonitorModule.removePeer(userId);
    updateMonitorButton();
  }

  function resetAll() {
    global.NetworkMonitorModule.stop();
    global.NetworkMonitorModule.clearAllPeers();
    latestSamples.clear();
    peerNames.clear();
    selectedUserId = null;
    if (els.osiStackOut) els.osiStackOut.querySelectorAll(".nf-packet").forEach((el) => el.remove());
    if (els.osiStackIn) els.osiStackIn.querySelectorAll(".nf-packet").forEach((el) => el.remove());
    renderPeerTabs();
    renderEmptyStats();
    updateMonitorButton();
  }

  function init() {
    cacheDom();
    if (!els.panel) {
      return; // Network flow markup not present on this page; no-op.
    }
    renderLane(els.osiStackOut, "out");
    renderLane(els.osiStackIn, "in");
    renderOsiInfoList();
    renderEmptyStats();
    updateMonitorButton();

    els.monitorButton.addEventListener("click", toggleMonitoring);
    els.eduToggle.addEventListener("change", () => {
      educationalMode = els.eduToggle.checked;
      if (!educationalMode) {
        els.osiExplain.hidden = true;
      }
    });
  }

  global.NetworkFlowUI = {
    init,
    registerPeer,
    unregisterPeer,
    setPeerName,
    resetAll,
  };
})(window);
