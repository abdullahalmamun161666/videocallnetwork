(function initApp(global) {
  const localVideoEl = document.getElementById("localVideo");
  const remoteVideosEl = document.getElementById("remoteVideos");
  const nameInputEl = document.getElementById("nameInput");
  const setNameButtonEl = document.getElementById("setNameButton");
  const currentUserTextEl = document.getElementById("currentUserText");
  const onlineUsersListEl = document.getElementById("onlineUsersList");
  const groupNameInputEl = document.getElementById("groupNameInput");
  const createGroupButtonEl = document.getElementById("createGroupButton");
  const groupsListEl = document.getElementById("groupsList");
  const groupStatusTextEl = document.getElementById("groupStatusText");
  const statusTextEl = document.getElementById("statusText");
  const callTextEl = document.getElementById("callText");
  const incomingCallBannerEl = document.getElementById("incomingCallBanner");
  const incomingCallTextEl = document.getElementById("incomingCallText");
  const acceptCallButtonEl = document.getElementById("acceptCallButton");
  const declineCallButtonEl = document.getElementById("declineCallButton");
  const endCallButtonEl = document.getElementById("endCallButton");
  const toggleAudioButtonEl = document.getElementById("toggleAudioButton");
  const toggleVideoButtonEl = document.getElementById("toggleVideoButton");

  const signaling = global.SignalingModule.createSignalingClient();
  let localStream = null;
  let currentUser = null;
  let onlineUsers = [];
  let activeRoomId = "";
  let activeCallPeer = null;
  let pendingIncomingCall = null;
  let availableGroups = [];
  let currentGroup = null;
  const remoteVideoElements = {};

  function setStatus(message) {
    statusTextEl.textContent = message;
    console.log(`[status] ${message}`);
  }

  function setCallText(message) {
    callTextEl.textContent = message;
  }

  function setGroupStatusText() {
    if (!currentGroup) {
      groupStatusTextEl.textContent = "No group selected";
      return;
    }
    const memberCount = Object.keys(remoteVideoElements).length + 1;
    groupStatusTextEl.textContent = `In "${currentGroup.name}" (${memberCount} in call)`;
  }

  function setCurrentUserText() {
    if (!currentUser) {
      currentUserTextEl.textContent = "Not registered";
      return;
    }
    currentUserTextEl.textContent = `You: ${currentUser.name} (${currentUser.userId.slice(0, 6)})`;
  }

  function canStartNewCall() {
    return Boolean(currentUser) && !activeRoomId;
  }

  function buildDefaultName() {
    const socketId = signaling.getSocketId() || "";
    return `User-${socketId.slice(0, 5) || "Guest"}`;
  }

  function updateCallControlState() {
    const inCall = Boolean(activeRoomId);
    endCallButtonEl.disabled = !inCall;
    if (!inCall) {
      setCallText("No active call");
    } else if (currentGroup) {
      setCallText(`In group call: ${currentGroup.name}`);
    } else {
      setCallText(`In call with ${activeCallPeer ? activeCallPeer.name : "participant"}`);
    }
  }

  function showIncomingCall(fromName) {
    incomingCallTextEl.textContent = `Incoming call from ${fromName}`;
    incomingCallBannerEl.classList.remove("hidden");
  }

  function hideIncomingCall() {
    pendingIncomingCall = null;
    incomingCallBannerEl.classList.add("hidden");
  }

  function renderRemoteStream(userId, stream) {
    let tile = remoteVideoElements[userId];
    if (!tile) {
      const wrapper = document.createElement("div");
      wrapper.className = "remote-tile";
      wrapper.dataset.userId = userId;

      const label = document.createElement("p");
      const remoteUser = onlineUsers.find((user) => user.userId === userId);
      label.textContent = `User: ${remoteUser ? remoteUser.name : userId}`;
      // ===== NETWORK MONITORING FEATURE =====
      if (remoteUser) {
        global.NetworkFlowUI.setPeerName(userId, remoteUser.name);
      }

      const video = document.createElement("video");
      video.autoplay = true;
      video.playsInline = true;

      wrapper.appendChild(label);
      wrapper.appendChild(video);
      remoteVideosEl.appendChild(wrapper);

      tile = { wrapper, video };
      remoteVideoElements[userId] = tile;
    }

    if (tile.video.srcObject !== stream) {
      tile.video.srcObject = stream;
    }
  }

  function removeRemoteStream(userId) {
    const tile = remoteVideoElements[userId];
    if (tile) {
      tile.wrapper.remove();
      delete remoteVideoElements[userId];
    }
  }

  function clearAllRemoteStreams() {
    Object.keys(remoteVideoElements).forEach(removeRemoteStream);
  }

  function renderOnlineUsers() {
    onlineUsersListEl.innerHTML = "";
    const myId = currentUser ? currentUser.userId : signaling.getSocketId();
    const others = onlineUsers.filter((user) => user.userId !== myId);

    if (others.length === 0) {
      const item = document.createElement("li");
      item.className = "online-item";
      item.innerHTML = "<span>No other users online</span>";
      onlineUsersListEl.appendChild(item);
      return;
    }

    others.forEach((user) => {
      const item = document.createElement("li");
      item.className = "online-item";

      const meta = document.createElement("div");
      const name = document.createElement("strong");
      name.textContent = user.name;
      const id = document.createElement("small");
      id.textContent = user.userId;
      meta.appendChild(name);
      meta.appendChild(document.createElement("br"));
      meta.appendChild(id);

      const callButton = document.createElement("button");
      callButton.type = "button";
      callButton.className = "call-button";
      callButton.textContent = "Call";
      callButton.disabled = !canStartNewCall();
      callButton.addEventListener("click", () => {
        startOutgoingCall(user);
      });

      item.appendChild(meta);
      item.appendChild(callButton);
      onlineUsersListEl.appendChild(item);
    });
  }

  function renderGroups() {
    groupsListEl.innerHTML = "";

    if (availableGroups.length === 0) {
      const item = document.createElement("li");
      item.className = "online-item";
      item.innerHTML = "<span>No groups yet. Create one above.</span>";
      groupsListEl.appendChild(item);
      return;
    }

    availableGroups.forEach((group) => {
      const item = document.createElement("li");
      item.className = "online-item";

      const meta = document.createElement("div");
      const name = document.createElement("strong");
      name.textContent = group.name;
      const info = document.createElement("small");
      info.textContent = `Created by: ${group.creatorName} · Members: ${group.memberCount}`;
      meta.appendChild(name);
      meta.appendChild(document.createElement("br"));
      meta.appendChild(info);

      const joinButton = document.createElement("button");
      joinButton.type = "button";
      joinButton.className = "call-button";
      joinButton.textContent = currentGroup && currentGroup.roomId === group.roomId ? "Joined" : "Join Group";
      joinButton.disabled =
        (Boolean(activeRoomId) && !(currentGroup && currentGroup.roomId === group.roomId)) ||
        (currentGroup && currentGroup.roomId === group.roomId);
      joinButton.addEventListener("click", () => {
        joinGroupFromList(group);
      });

      item.appendChild(meta);
      item.appendChild(joinButton);
      groupsListEl.appendChild(item);
    });
  }

  function createOrGetPeer(userId) {
    if (global.PeersModule.hasPeer(userId)) {
      return global.PeersModule.getPeer(userId);
    }

    const pc = global.PeersModule.createPeerConnection(userId, {
      localStream,
      onRemoteTrack: renderRemoteStream,
      onIceCandidate: (targetUserId, candidate) => {
        signaling.sendIceCandidate(targetUserId, candidate);
      },
      onConnectionStateChange: (remoteUserId, state) => {
        if (state === "failed" || state === "closed") {
          global.PeersModule.closePeer(remoteUserId);
          // ===== NETWORK MONITORING FEATURE =====
          global.NetworkFlowUI.unregisterPeer(remoteUserId);
          removeRemoteStream(remoteUserId);
        }
      },
    });

    // ===== NETWORK MONITORING FEATURE =====
    // createOrGetPeer() is the single place BOTH 1:1 calls (via
    // onCallAccepted/handleIncomingOffer) and group/mesh calls (via
    // onAllUsers/onUserJoined) create a peer connection, so registering here
    // covers every call mode automatically -- no second PeerConnection, no
    // separate monitoring path for group vs 1:1.
    const remoteUser = onlineUsers.find((user) => user.userId === userId);
    global.NetworkFlowUI.registerPeer(userId, pc, remoteUser ? remoteUser.name : userId);

    return pc;
  }

  async function createAndSendOffer(userId) {
    const pc = createOrGetPeer(userId);
    if (pc.signalingState !== "stable") {
      return;
    }
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    signaling.sendOffer(userId, pc.localDescription);
  }

  async function handleIncomingOffer(senderUserId, sdp) {
    const pc = createOrGetPeer(senderUserId);
    if (pc.signalingState !== "stable") {
      try {
        await pc.setLocalDescription({ type: "rollback" });
      } catch (_error) {
        // no-op: keep app resilient on unsupported rollback
      }
    }
    await global.PeersModule.setRemoteDescription(senderUserId, sdp);
    const answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);
    signaling.sendAnswer(senderUserId, pc.localDescription);
  }

  async function startLocalMedia() {
    if (localStream) {
      return localStream;
    }

    localStream = await navigator.mediaDevices.getUserMedia({
      video: true,
      audio: {
        // Reduce acoustic feedback/echo in typical speakerphone setups.
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
      },
    });

    localVideoEl.muted = true;
    localVideoEl.srcObject = localStream;
    toggleAudioButtonEl.disabled = false;
    toggleVideoButtonEl.disabled = false;
    return localStream;
  }

  async function ensureLocalMedia() {
    try {
      await startLocalMedia();
      return true;
    } catch (error) {
      console.error(error);
      setStatus("Failed to access media devices.");
      return false;
    }
  }

  function toggleTrack(kind, buttonEl, enabledText, disabledText) {
    if (!localStream) {
      return;
    }
    const track = localStream.getTracks().find((item) => item.kind === kind);
    if (!track) {
      return;
    }
    track.enabled = !track.enabled;
    buttonEl.textContent = track.enabled ? enabledText : disabledText;
  }

  function setActiveCall(peerUserId) {
    const user = onlineUsers.find((item) => item.userId === peerUserId);
    activeCallPeer = user || { userId: peerUserId, name: peerUserId };
    updateCallControlState();
    renderOnlineUsers();
  }

  async function joinRoomById(roomId) {
    if (!roomId) {
      return;
    }
    activeRoomId = roomId;
    signaling.joinRoom(roomId);
    updateCallControlState();
    setStatus(`Joined call room ${roomId}`);
  }

  function endActiveCall() {
    if (!activeRoomId) {
      return;
    }

    signaling.leaveRoom();
    global.PeersModule.closeAllPeers();
    // ===== NETWORK MONITORING FEATURE =====
    global.NetworkFlowUI.resetAll();
    clearAllRemoteStreams();
    activeRoomId = "";
    activeCallPeer = null;
    currentGroup = null;
    updateCallControlState();
    setGroupStatusText();
    renderOnlineUsers();
    renderGroups();
    setStatus("Call ended.");
  }

  async function startOutgoingCall(user) {
    if (!canStartNewCall()) {
      return;
    }
    if (!(await ensureLocalMedia())) {
      return;
    }
    setActiveCall(user.userId);
    setStatus(`Calling ${user.name}...`);
    signaling.callUser(user.userId);
  }

  function createGroup() {
    const groupName = groupNameInputEl.value.trim();
    if (!groupName) {
      setStatus("Enter a group name first.");
      return;
    }
    signaling.createGroup(groupName);
    groupNameInputEl.value = "";
  }

  async function joinGroupFromList(group) {
    if (activeRoomId && !(currentGroup && currentGroup.roomId === group.roomId)) {
      setStatus("End your current call before joining another group.");
      return;
    }
    if (currentGroup && currentGroup.roomId === group.roomId) {
      return;
    }
    if (!(await ensureLocalMedia())) {
      return;
    }

    currentGroup = group;
    activeCallPeer = null;
    setGroupStatusText();
    renderGroups();

    await joinRoomById(group.roomId);
    setStatus(`Joined group "${group.name}".`);
  }

  function registerName() {
    const typedName = nameInputEl.value.trim();
    const nameToRegister = typedName || buildDefaultName();
    nameInputEl.value = nameToRegister;
    signaling.registerUser(nameToRegister);
  }

  signaling.onConnect(() => {
    setStatus(`Connected to signaling server as ${signaling.getSocketId()}`);
    if (!nameInputEl.value.trim()) {
      nameInputEl.value = buildDefaultName();
    }
    registerName();
  });

  signaling.onDisconnect(() => {
    setStatus("Disconnected from signaling server.");
    global.PeersModule.closeAllPeers();
    // ===== NETWORK MONITORING FEATURE =====
    global.NetworkFlowUI.resetAll();
    clearAllRemoteStreams();
    activeRoomId = "";
    activeCallPeer = null;
    currentUser = null;
    onlineUsers = [];
    availableGroups = [];
    currentGroup = null;
    setCurrentUserText();
    updateCallControlState();
    setGroupStatusText();
    renderOnlineUsers();
    renderGroups();
    toggleAudioButtonEl.disabled = true;
    toggleVideoButtonEl.disabled = true;
    localVideoEl.srcObject = null;
    localStream = null;
  });

  signaling.onUserRegistered(({ userId, name }) => {
    currentUser = { userId, name };
    setCurrentUserText();
    setStatus(`Signed in as ${name}`);
    renderOnlineUsers();
  });

  signaling.onOnlineUsers((users) => {
    onlineUsers = users;
    renderOnlineUsers();
  });

  signaling.onIncomingCall(async ({ fromUserId, fromName, roomId }) => {
    if (activeRoomId) {
      signaling.declineCall(fromUserId);
      return;
    }
    pendingIncomingCall = { fromUserId, fromName, roomId };
    showIncomingCall(fromName);
  });

  signaling.onCallAccepted(async ({ byUserId, roomId }) => {
    if (!(await ensureLocalMedia())) {
      return;
    }
    setActiveCall(byUserId);
    await joinRoomById(roomId);
  });

  signaling.onCallDeclined(({ byUserId }) => {
    const user = onlineUsers.find((item) => item.userId === byUserId);
    setStatus(`${user ? user.name : "User"} declined the call.`);
    activeCallPeer = null;
    updateCallControlState();
    renderOnlineUsers();
  });

  signaling.onGroupCreated((group) => {
    setStatus(`Group "${group.name}" created. Click "Join Group" when you're ready.`);
  });

  signaling.onAvailableGroups((groups) => {
    availableGroups = groups;
    if (currentGroup) {
      const updated = availableGroups.find((group) => group.roomId === currentGroup.roomId);
      if (updated) {
        currentGroup = updated;
        setGroupStatusText();
      }
    }
    renderGroups();
  });

  signaling.onErrorMessage(({ message }) => {
    setStatus(message || "Server error.");
  });

  signaling.onAllUsers(async (users) => {
    for (const userId of users) {
      try {
        await createAndSendOffer(userId);
      } catch (error) {
        console.error(`[peer:${userId}] offer flow failed`, error);
      }
    }
  });

  signaling.onUserJoined(({ userId }) => {
    if (!activeRoomId) {
      return;
    }
    setStatus(`User joined call: ${userId}`);
    if (currentGroup) {
      setGroupStatusText();
    }
  });

  signaling.onOffer(async ({ senderUserId, sdp }) => {
    try {
      await handleIncomingOffer(senderUserId, sdp);
    } catch (error) {
      console.error(`[peer:${senderUserId}] handle offer failed`, error);
    }
  });

  signaling.onAnswer(async ({ senderUserId, sdp }) => {
    try {
      await global.PeersModule.setRemoteDescription(senderUserId, sdp);
    } catch (error) {
      console.error(`[peer:${senderUserId}] handle answer failed`, error);
    }
  });

  signaling.onIceCandidate(async ({ senderUserId, candidate }) => {
    if (!candidate) {
      return;
    }
    if (!global.PeersModule.hasPeer(senderUserId)) {
      createOrGetPeer(senderUserId);
    }
    try {
      await global.PeersModule.addIceCandidate(senderUserId, candidate);
    } catch (error) {
      console.error(`[peer:${senderUserId}] add candidate failed`, error);
    }
  });

  signaling.onUserLeft(({ userId }) => {
    global.PeersModule.closePeer(userId);
    // ===== NETWORK MONITORING FEATURE =====
    global.NetworkFlowUI.unregisterPeer(userId);
    removeRemoteStream(userId);
    setStatus(`User left call: ${userId}`);
    if (currentGroup) {
      setGroupStatusText();
    }
    if (Object.keys(remoteVideoElements).length === 0 && activeRoomId && !currentGroup) {
      activeRoomId = "";
      activeCallPeer = null;
      updateCallControlState();
      renderOnlineUsers();
    }
  });

  async function acceptIncomingCall() {
    if (!pendingIncomingCall) {
      return;
    }
    const { fromUserId, roomId } = pendingIncomingCall;
    hideIncomingCall();
    if (!(await ensureLocalMedia())) {
      signaling.declineCall(fromUserId);
      return;
    }
    setActiveCall(fromUserId);
    signaling.acceptCall(fromUserId, roomId);
    await joinRoomById(roomId);
  }

  function declineIncomingCall() {
    if (!pendingIncomingCall) {
      return;
    }
    signaling.declineCall(pendingIncomingCall.fromUserId);
    hideIncomingCall();
    setStatus("Incoming call declined.");
  }

  setNameButtonEl.addEventListener("click", registerName);
  nameInputEl.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      registerName();
    }
  });
  createGroupButtonEl.addEventListener("click", createGroup);
  groupNameInputEl.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      createGroup();
    }
  });
  endCallButtonEl.addEventListener("click", endActiveCall);
  acceptCallButtonEl.addEventListener("click", () => {
    acceptIncomingCall();
  });
  declineCallButtonEl.addEventListener("click", declineIncomingCall);

  toggleAudioButtonEl.addEventListener("click", () => {
    toggleTrack("audio", toggleAudioButtonEl, "Mute", "Unmute");
  });
  toggleVideoButtonEl.addEventListener("click", () => {
    toggleTrack("video", toggleVideoButtonEl, "Camera Off", "Camera On");
  });

  setCurrentUserText();
  setCallText("No active call");
  setGroupStatusText();
  hideIncomingCall();
  renderOnlineUsers();
  renderGroups();
  // ===== NETWORK MONITORING FEATURE =====
  global.NetworkFlowUI.init();
})(window);
