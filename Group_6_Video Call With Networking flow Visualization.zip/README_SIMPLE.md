
## ধাপে ধাপে সম্পূর্ণ সেটআপ

## A) নতুন ল্যাপটপে প্রথমবার সেটআপ

### ১) প্রয়োজনীয় সফটওয়্যার ইনস্টল করুন

ইনস্টল করুন:
- Node.js 18+ (LTS হলে ভালো)
- VS Code

`mkcert` ইনস্টল:

```powershell
winget install --id FiloSottile.mkcert -e --accept-source-agreements --accept-package-agreements
```
Side note (কোথা থেকে run করবেন): যেকোনো location থেকে চালানো যাবে।

`cloudflared` ইনস্টল:

```powershell
winget install --id Cloudflare.cloudflared -e --accept-source-agreements --accept-package-agreements
```
Side note (কোথা থেকে run করবেন): যেকোনো location থেকে চালানো যাবে।

### ২) পুরো project folder কপি করুন

আপনি যেহেতু পুরো folder দিবেন, তাই git clone লাগবে না।

উদাহরণ path:
- `G:\projects\video_call`

### ৩) VS Code দিয়ে folder open করুন

```powershell
code .
```
Side note (কোথা থেকে run করবেন): `G:\projects\video_call` folder এ দাঁড়িয়ে চালান।

এরপর VS Code থেকে Terminal খুলুন:
- **Terminal -> New Terminal**

### ৪) Dependencies ইনস্টল করুন

```powershell
npm install
cd server
npm install
cd ..
```
Side note (কোথা থেকে run করবেন): শুরুতেই `G:\projects\video_call` এ থাকতে হবে।

### ৫) HTTPS certificate তৈরি করুন (এই ল্যাপটপের জন্য)

Local CA install:

```powershell
& "$env:LOCALAPPDATA\Microsoft\WinGet\Links\mkcert.exe" -install
```
Side note (কোথা থেকে run করবেন): যেকোনো location থেকে চালানো যাবে।

Cert folder তৈরি:

```powershell
mkdir server\certs
```
Side note (কোথা থেকে run করবেন): `G:\projects\video_call` folder থেকে চালান।

ল্যাপটপের IP দেখুন:

```powershell
ipconfig
```
Side note (কোথা থেকে run করবেন): যেকোনো location থেকে চালানো যাবে।

IPv4 দেখে cert তৈরি করুন:

```powershell
& "$env:LOCALAPPDATA\Microsoft\WinGet\Links\mkcert.exe" -key-file "server\certs\dev-key.pem" -cert-file "server\certs\dev-cert.pem" localhost 127.0.0.1 <YOUR_LAPTOP_IP>
```
Side note (কোথা থেকে run করবেন): `G:\projects\video_call` folder থেকে চালান।

উদাহরণ:

```powershell
& "$env:LOCALAPPDATA\Microsoft\WinGet\Links\mkcert.exe" -key-file "server\certs\dev-key.pem" -cert-file "server\certs\dev-cert.pem" localhost 127.0.0.1 192.168.1.25
```
Side note (কোথা থেকে run করবেন): `G:\projects\video_call` folder থেকে চালান।

## B) কল সার্ভার চালু করা এবং URL শেয়ার করা

### ১) Login credentials সেট করুন (একই টার্মিনালে)

```powershell
$env:AUTH_USERNAME='your_username'
$env:AUTH_PASSWORD='your_password'
$env:SESSION_SECRET='your_long_random_secret'
```
Side note (কোথা থেকে run করবেন): যে terminal থেকে server run করবেন, সেই একই terminal এ চালান।

নোট:
- PowerShell এ single quote `'...'` ব্যবহার করুন।
- Password এ `$` থাকলে single quote অবশ্যই দিন।

### ২) Secure call server চালু করুন

```powershell
npm run start:https
```

গুরুত্বপূর্ণ:
- এই কমান্ড root folder (`G:\projects\video_call`) থেকে চালান।
- যদি `server` folder এর ভিতরে থাকেন, তখন চালান: `npm run start:https`

Expected output:
- `Signaling server running on https://localhost:3443`

যদি `EADDRINUSE` আসে, বুঝবেন 3443 port আগে থেকেই use হচ্ছে। পুরনো node process বন্ধ করে আবার চালান।

### ৩) Cloudflare tunnel চালু করুন (নতুন টার্মিনাল)

VS Code-এ নতুন টার্মিনাল খুলে চালান:

```powershell
& "C:\Program Files (x86)\cloudflared\cloudflared.exe" tunnel --url https://localhost:3443 --no-tls-verify
```
Side note (কোথা থেকে run করবেন): নতুন terminal খুলে `G:\projects\video_call` থেকে চালানো ভালো।

এখানে একটি public URL পাবেন:
- `https://xxxx.trycloudflare.com`

### ৪) টিমের সাথে শেয়ার করুন

শেয়ার করুন:
- Tunnel URL (`https://...trycloudflare.com`)
- Username/password

## C) টিমের কল করার নিয়ম

প্রতিটি টিম মেম্বার:
1. Tunnel URL ওপেন করবে।
2. Username/password দিয়ে login করবে।
3. Display name লিখে **Set Name** চাপবে।
4. **Online Users** এ অন্য ইউজার আসা পর্যন্ত অপেক্ষা করবে।
5. কাউকে কল দিতে **Call** চাপবে।
6. যাকে কল দেয়া হয়েছে সে **Accept** চাপবে।
7. প্রয়োজন হলে **Mute**, **Camera Off**, **End Call** ব্যবহার করবে।

## D) ল্যাপটপ রিস্টার্টের পর কী কী আবার করতে হবে

আবার এই ধাপগুলো করুন:
1. Auth env vars সেট করুন (`AUTH_USERNAME`, `AUTH_PASSWORD`, `SESSION_SECRET`)।
2. সার্ভার চালু করুন: `npm run start:https`।
3. নতুন টার্মিনালে tunnel চালু করুন।
4. নতুন tunnel URL টিমকে শেয়ার করুন (URL পরিবর্তন হতে পারে)।
